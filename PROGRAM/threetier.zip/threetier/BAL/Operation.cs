﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using BEL;

namespace BAL
{
    public class Operation
    {
        public Dbconnection db = new Dbconnection();
        public Informations info = new Informations();

    }
}
